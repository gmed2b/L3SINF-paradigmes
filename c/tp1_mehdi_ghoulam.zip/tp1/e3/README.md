# Exercice 3 - Gestion des horaires de trains

J'ai crée dans le fichier 'train_managment.c' la librairie contenant les fonctions permettant de gérer les horaires des trains. J'ai également crée un fichier 'main.c' qui permet de tester les fonctions de la librairie.
